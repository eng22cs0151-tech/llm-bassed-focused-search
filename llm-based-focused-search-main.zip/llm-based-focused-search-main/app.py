from flask import Flask
from app.routes import routes_bp  # Ensure correct import path

app = Flask(__name__, template_folder="templates")  # Adjust path if necessary
app.register_blueprint(routes_bp)

if __name__ == "__main__":
    app.run( debug=True)

import os
print("Template Directory:", app.template_folder)
print("Available Templates:", os.listdir(app.template_folder))
