from flask import Blueprint, request, jsonify, render_template
from app.search import google_search
from app.summarizer import summarize_text
from app.scraper import scrape_website

routes_bp = Blueprint("routes", __name__)

@routes_bp.route("/")
def index():
    return render_template("index.html")

@routes_bp.route("/search", methods=["GET"])
def search():
    query = request.args.get("q", "")
    if not query:
        return jsonify({"error": "Query parameter missing"}), 400
    
    results = google_search(query)
    return jsonify({"results": results})

@routes_bp.route("/summarize", methods=["POST"])
def summarize():
    data = request.json
    text = data.get("text", "")
    
    if not text:
        return jsonify({"error": "No text provided"}), 400

    summary = summarize_text(text)
    return jsonify({"summary": summary})

@routes_bp.route("/scrape", methods=["POST"])
def scrape():
    data = request.json
    url = data.get("url", "")

    if not url:
        return jsonify({"error": "No URL provided"}), 400

    content = scrape_website(url)
    return jsonify({"content": content})
