import requests
from bs4 import BeautifulSoup

def scrape_website(url):
    headers = {"User-Agent": "Mozilla/5.0"}
    
    try:
        response = requests.get(url, headers=headers)
        soup = BeautifulSoup(response.text, "html.parser")

        content = " ".join([p.text for p in soup.find_all("p")])
        print(content)
        return content if content else "No content found."
    
    except Exception as e:
        return f"Error scraping: {str(e)}"
