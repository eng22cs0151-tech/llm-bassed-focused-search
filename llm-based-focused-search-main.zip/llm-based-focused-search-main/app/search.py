import requests
from config import GOOGLE_CSE_ID, GOOGLE_API_KEY

GOOGLE_SEARCH_URL = "https://www.googleapis.com/customsearch/v1"

def google_search(query):
    params = {
        "q": query,
        "cx": GOOGLE_CSE_ID,
        "key": GOOGLE_API_KEY,
        "num": 5
    }
    
    response = requests.get(GOOGLE_SEARCH_URL, params=params)
    return response.json().get("items", [])
