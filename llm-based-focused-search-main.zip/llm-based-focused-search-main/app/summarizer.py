import requests
from config import GEMINI_API_KEY

def summarize_text(text):
    if not text:
        return "No content available for summarization."

    url = f"https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent?key={GEMINI_API_KEY}"
    
    payload = {"contents": [{"parts": [{"text": text}]}]}
    headers = {"Content-Type": "application/json"}
    
    response = requests.post(url, json=payload, headers=headers)
    
    try:
        summary = response.json()["candidates"][0]["content"]["parts"][0]["text"]
        return summary
    except Exception as e:
        return f"Error summarizing: {str(e)}"
