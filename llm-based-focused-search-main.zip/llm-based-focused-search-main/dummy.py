from flask import Flask, render_template, request, jsonify
import requests
from bs4 import BeautifulSoup

# Load API keys from environment variables (replace with your method of storage)
GOOGLE_CSE_ID = "540342a922d114f27"
GOOGLE_API_KEY = "AIzaSyAme57IGJvAUXDhrmpc70HDOyVAtNYktE8"
GEMINI_API_KEY = "AIzaSyBXOjj7FzhOfz-4vlUQ4-x7X-S2aOhZReU"

GOOGLE_SEARCH_URL = "https://www.googleapis.com/customsearch/v1"
GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent"

#https://www.googleapis.com/customsearch/v1?q=f1&cx=AIzaSyDdPofA9tmI7UkQaqjibgFj1_L8DTPWh14&key=AIzaSyAme57IGJvAUXDhrmpc70HDOyVAtNYktE8


app = Flask(__name__)

# Function to perform Google Search
def google_search(query):
    params = {
        "q": query,
        "cx": GOOGLE_CSE_ID,
        "key": GOOGLE_API_KEY,
        "num": 5  # Limit number of results
    }
    try:
        response = requests.get(GOOGLE_SEARCH_URL, params=params)
        response.raise_for_status()
        return response.json().get("items", [])
    except requests.exceptions.RequestException as e:
        return []

# Function to scrape a webpage
def scrape_website(url):
    headers = {"User-Agent": "Mozilla/5.0"}
    try:
        response = requests.get(url, headers=headers)
        soup = BeautifulSoup(response.text, "html.parser")
        content = " ".join([p.text for p in soup.find_all("p")])
        print(content)
        return content if content else "No content found."
    except Exception as e:
        return f"Error scraping: {str(e)}"

# Function to summarize text using Gemini API
def summarize_text(text):
    if not text:
        return "No content available for summarization."
    
    payload = {"contents": [{"parts": [{"text": text}]}]}
    headers = {"Content-Type": "application/json"}
    try:
        response = requests.post(f"{GEMINI_API_URL}?key={GEMINI_API_KEY}", json=payload, headers=headers)
        response.raise_for_status()
        return response.json()["candidates"][0]["content"]["parts"][0]["text"]
    except Exception as e:
        return f"Error summarizing: {str(e)}"

# Route for rendering the frontend
@app.route('/')
def index():
    return render_template("dummy.html")

# Route to handle search requests
@app.route('/search', methods=['GET'])
def search():
    query = request.args.get("q", "")
    if not query:
        return jsonify({"error": "Query parameter is missing."})
    
    results = google_search(query)
    return jsonify({"results": results})

# Route to handle scraping and summarization
@app.route('/scrape_summarize', methods=['POST'])
def scrape_and_summarize():
    data = request.json
    url = data.get("url")
    if not url:
        return jsonify({"error": "URL parameter is missing."})
    
    content = scrape_website(url)
    summary = summarize_text(content)
    return jsonify({"summary": summary})

if __name__ == "__main__":
    app.run(debug=True)
