from flask import Flask, render_template, request, jsonify
import requests
from bs4 import BeautifulSoup

# Load API keys
GOOGLE_CSE_ID = "540342a922d114f27"
GOOGLE_API_KEY = "AIzaSyAme57IGJvAUXDhrmpc70HDOyVAtNYktE8"
GEMINI_API_KEY = "AIzaSyBXOjj7FzhOfz-4vlUQ4-x7X-S2aOhZReU"

GOOGLE_SEARCH_URL = "https://www.googleapis.com/customsearch/v1"
GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent"

app = Flask(__name__)

# Google Search Function
def google_search(query):
    params = {"q": query, "cx": GOOGLE_CSE_ID, "key": GOOGLE_API_KEY, "num": 5}
    try:
        response = requests.get(GOOGLE_SEARCH_URL, params=params)
        response.raise_for_status()
        return response.json().get("items", [])
    except requests.exceptions.RequestException:
        return []

# Scrape Website Content
def scrape_website(url):
    headers = {"User-Agent": "Mozilla/5.0"}
    try:
        response = requests.get(url, headers=headers, timeout=5)
        soup = BeautifulSoup(response.text, "html.parser")
        content = " ".join([p.text for p in soup.find_all("p")])
        return content if content else "No content found."
    except Exception:
        return "Error scraping."

# Summarize Text Using Gemini API
def summarize_text(text):
    if not text:
        return "No content available for summarization."
    
    payload = {"contents": [{"parts": [{"text": text}]}]}
    headers = {"Content-Type": "application/json"}
    try:
        response = requests.post(f"{GEMINI_API_URL}?key={GEMINI_API_KEY}", json=payload, headers=headers)
        response.raise_for_status()
        return response.json()["candidates"][0]["content"]["parts"][0]["text"]
    except Exception:
        return "Error summarizing."

# Generate Final Summary from All Summaries
def generate_final_summary(question, summaries):
    combined_text = " ".join(summaries)  
    prompt = f"Based on the following information, answer the question: '{question}'. Summarize concisely:\n\n{combined_text}"
    
    payload = {"contents": [{"parts": [{"text": prompt}]}]}
    headers = {"Content-Type": "application/json"}
    
    try:
        response = requests.post(f"{GEMINI_API_URL}?key={GEMINI_API_KEY}", json=payload, headers=headers)
        response.raise_for_status()
        return response.json()["candidates"][0]["content"]["parts"][0]["text"]
    except Exception:
        return "Error generating final summary."

# Search, Scrape, Summarize, and Generate Final Summary
@app.route('/')
def index():
    return render_template("dummy2.html")
@app.route('/search_summarize', methods=['GET'])
def search_and_summarize():
    query = request.args.get("q", "")
    if not query:
        return jsonify({"error": "Query parameter is missing."})

    results = google_search(query)
    urls = [item["link"] for item in results]
    
    summaries = []
    for url in urls:
        content = scrape_website(url)
        summary = summarize_text(content)
        summaries.append(summary)

    final_summary = generate_final_summary(query, summaries)

    return jsonify({
        "summaries": [{"url": url, "summary": summary} for url, summary in zip(urls, summaries)],
        "final_summary": final_summary
    })

if __name__ == "__main__":
    app.run(debug=True)
