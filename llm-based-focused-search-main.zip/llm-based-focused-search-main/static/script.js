document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("searchButton").addEventListener("click", search);
});

async function search() {
    let query = document.getElementById("searchQuery").value;
    console.log("Searching for:", query);  // ✅ Debugging log

    try {
        let response = await fetch(`/search?q=${encodeURIComponent(query)}`);
        
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        let data = await response.json();
        console.log("Response Data:", data);  // ✅ Debugging log

        let resultsDiv = document.getElementById("results");
        resultsDiv.innerHTML = "";

        if (!data.results || data.results.length === 0) {
            resultsDiv.innerHTML = "<p>No results found.</p>";
            return;
        }

        data.results.forEach(item => {
            let div = document.createElement("div");
            div.innerHTML = `
                <h3><a href="${item.link}" target="_blank">${item.title}</a></h3>
                <p>${item.snippet}</p>
            `;
            resultsDiv.appendChild(div);
        });
    } catch (error) {
        console.error("Error:", error);
        document.getElementById("results").innerHTML = "<p>Error fetching results. Please try again later.</p>";
    }
}